#!/bin/bash

ruby ./main.rb